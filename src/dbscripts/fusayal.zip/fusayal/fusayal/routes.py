def includeme(config):
    config.add_static_view('static', 'static', cache_max_age=3600)
    #config.add_route('home', '/')
    config.add_route('initApp', '/')
    config.add_route('loginApp', '/login')
    config.add_route('logoutApp', '/logout')
    config.add_route('homeApp', '/home')
    config.add_route('home', '/prhome')
