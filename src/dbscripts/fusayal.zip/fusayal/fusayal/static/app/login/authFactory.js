(function () {
    'use strict';
    angular.module("isyplus")
        .factory("AuthFactory", AuthFactory);

    function AuthFactory(){
        var userLogged = false;
        return {
            isUserLogged:isUserLogged,
            setUserLogged:setUserLogged
        }

        function isUserLogged() {
            return userLogged;
        }

        function setUserLogged(pUserLogged){
            userLogged = pUserLogged;
        }
    }

})();